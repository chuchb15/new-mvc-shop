/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","id",{button:"Masukkan potongan kode",codeContents:"Konten kode",emptySnippetError:"Potongan kode tidak boleh kosong",language:"Bahasa",title:"Potongan kode",pathName:"potongan kode"});